Exported at 2026-04-02T01:59:04Z

Query: q=racoon&quality_grade=any&identifications=any&place_id=1930&taxon_id=41661&verifiable=true&spam=false

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on_string: Date/time as entered by the observer
observed_on: Normalized date of observation
created_at: Datetime observation was created
updated_at: Datetime observation was last updated
place_guess: Locality description as entered by the observer
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
private_place_guess: Observation location as written by the observer if location obscured
private_latitude: Private latitude, set if observation private or obscured
private_longitude: Private longitude, set if observation private or obscured
species_guess: Plain text name of the observed taxon; can be set by the observer during observation creation, but can get replaced with canonical, localized names when the taxon changes
common_name: Common or vernacular name of the observed taxon according to iNaturalist

For more information about column headers, see https://www.inaturalist.org/terminology

